ssid = "HAck-Project-WiFi-1"
mqtt_server = "mqtts://cabab558654e453d9b25d76f57219102.s1.eu.hivemq.cloud:8883"
mqtt_user = "picow"
mqtt_pass = "Fun1234!"
